[v2.0.0]
1.use commond "modprobe" to install/uninstall kernel modules
2.assign vermagic "4.0.0.02-xilinx"

