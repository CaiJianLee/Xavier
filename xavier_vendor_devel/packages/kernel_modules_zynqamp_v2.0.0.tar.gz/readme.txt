[v2.0.0]
1.update kernel version 4.9.0
2.use commond "modprobe" to install/uninstall kernel modules
3.assign vermagic "4.9.0-xilinx"

